<!--footer-->
    <div class="footer">
       <p>&copy; 2024 DJ Johnsons INTL || Admin Panel.</p>
    </div>
        <!--//footer-->